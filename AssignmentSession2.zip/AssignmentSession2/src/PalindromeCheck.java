import java.util.Scanner;

public class PalindromeCheck {
	public static void main (String s[])
	{
		Scanner scn= new Scanner(System.in);
		
		System.out.println("Please Enter the number ");
		int number,tempnumber , reminder=0,revr =0;   
		number= scn.nextInt();
		tempnumber=number;
		while (number>0)
		{
			reminder=number%10;
			revr=(revr*10)+reminder;
			number=number/10;							
		}
		
		if (revr==tempnumber)
		{
			System.out.println("Enter number "+tempnumber +" is palindrome");	
		}
		else 
		{
			System.out.println("Enter number "+tempnumber +" is not palindrome");
		}
		
		
     scn.close();
	}	
}
