import java.util.Scanner;
public class FactorialCalculation 
{
	public static void main (String s[])
	{
		Scanner scn= new Scanner(System.in);
		
		System.out.println("Please Enter the number");
		int number , factorial=1;
		number= scn.nextInt();
		
		for (int i=1; i<=number; i++)
		{
			factorial= factorial*i;			
		}
		System.out.println("Factorial for "+number +" is " + factorial);
     scn.close();
	}	
	
}
