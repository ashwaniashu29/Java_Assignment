import java.util.Scanner;


public class TableofEnteredNumber {
	public static void main(String str[])
	{
		Scanner scn= new Scanner(System.in);	
		System.out.println("Please Enter the number ");
		
		int number, calc =1;
		number= scn.nextInt();
		
		for (int i=1; i<=10; i++ )
		{
			calc =number*i;
			System.out.println(number +"*"+i+"="+calc); 		
		}
		scn.close();
	}

}
